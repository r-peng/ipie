# Fixed-partition channels: step 2

Prepared against r-peng/ipie branch lafqmc_thc, commit
bde0d697e10e8767e603a4064b7e1615cdabc548.

Choose one installation method:
1. Copy the ipie/ paths in this archive into your repository root.
2. OR, before copying those paths, apply cholesky_channels_step2.patch with
   git apply --check cholesky_channels_step2.patch
   git apply cholesky_channels_step2.patch

The patch passed git apply --check against the pinned original files.
Only six files in ipie/hamiltonians/optimize_cholesky are added/updated;
sor_base.py and existing tests/sor_test.py are unchanged.

Run from your configured ipie repository:
  python -m unittest discover -s ipie/hamiltonians/optimize_cholesky/tests -v
  python -m ipie.hamiltonians.optimize_cholesky.tests.test_channels

Validation in this environment: 34 targeted tests passed, 3 existing HDF5
tests skipped because h5py is unavailable. All 10 new step-2 tests passed.
The targeted harness loaded the actual source modules and bitstring helper
while bypassing unrelated top-level ipie startup imports in a partial local
checkout. The full installed ipie runtime/test suite was not exercised.
Reference examples had scaled Hamiltonian residuals below 4e-13.

Full API, fixed ratio conventions, source order, domain checks, and usage
are documented in ipie/hamiltonians/optimize_cholesky/README.md.
