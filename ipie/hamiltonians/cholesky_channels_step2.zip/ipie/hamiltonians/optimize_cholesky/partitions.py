"""Fixed term-local log partitions. No optimization or amplitude clipping."""

from numbers import Real

import numpy as np

from .validation import _real_array


def positive_scale(value, name):
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, Real):
        raise ValueError(f"{name} must be finite, real, and strictly positive")
    if not np.isfinite(value) or value <= 0:
        raise ValueError(f"{name} must be finite, real, and strictly positive")
    return float(value)


def fixed_partition_amplitudes(eigenvalues, sources, tau2, t=None,
                               partition="balanced_log", amplitude_bound=1.0):
    """Return owned (t, d) arrays, with d[i]=(d_left,d_right) for source i.

    balanced_log: sigma*sqrt(k)*exp(t), sigma*sign(-W)*sqrt(k)*exp(-t),
                  k=abs(W*tau2), sigma=sign(ell_left).
                  Both legs are zero if W=0.
    anchored_log: ell_left*sqrt(tau2)*exp(t),
                 -ell_right*sqrt(tau2)*exp(-t).

    t=None means zero log ratios; a finite scalar broadcasts to every source.
    All requested amplitudes must satisfy abs(d)<amplitude_bound<=1. The
    paired real-exponential domain is checked, never repaired by clipping.
    """
    tau2 = positive_scale(tau2, "tau2")
    bound = positive_scale(amplitude_bound, "amplitude_bound")
    if bound > 1:
        raise ValueError("amplitude_bound must be <=1 for paired real exponentials")
    if partition not in ("balanced_log", "anchored_log"):
        raise ValueError("partition must be 'balanced_log' or 'anchored_log'")
    ell = _real_array(eigenvalues, "eigenvalues")
    if ell.ndim != 2:
        raise ValueError("eigenvalues must have shape (r,n)")
    count = len(sources)
    if t is None:
        ratios = np.zeros(count, dtype=np.float64)
    else:
        supplied = _real_array(t, "t")
        if supplied.ndim == 0:
            ratios = np.full(count, float(supplied))
        elif supplied.shape == (count,):
            ratios = supplied.copy()
        else:
            raise ValueError(f"t must be a scalar or a length-{count} vector")
    amplitudes = np.zeros((count, 2), dtype=np.float64)
    log_tau = np.log(tau2)
    log_bound = np.log(bound)
    for i, source in enumerate(sources):
        g, (p, q) = source.bix, source.modes
        if not (0 <= g < ell.shape[0] and 0 <= p < ell.shape[1] and 0 <= q < ell.shape[1]):
            raise ValueError(f"Invalid basis or mode indices in source {i}")
        left, right = ell[g, p], ell[g, q]
        if partition == "balanced_log":
            if left == 0 or right == 0:
                continue  # fixed formal identity channels, positive analytic weights
            base = 0.5 * (np.log(abs(left)) + np.log(abs(right)) + log_tau)
            logs = (base + ratios[i], base - ratios[i])
        else:
            logs = ((-np.inf if left == 0 else np.log(abs(left)) + 0.5*log_tau + ratios[i]),
                    (-np.inf if right == 0 else np.log(abs(right)) + 0.5*log_tau - ratios[i]))
        if max(logs) >= log_bound:
            raise ValueError(
                f"Source {i} (bix={g}, modes={(p,q)}): partition leaves abs(d)<{bound}. "
                "Choose a smaller tau2 or a different fixed t; amplitudes were not clipped."
            )
        amplitudes[i] = (np.sign(left)*np.exp(logs[0]), -np.sign(right)*np.exp(logs[1]))
        if any(log != -np.inf and d == 0 for log, d in zip(logs, amplitudes[i])):
            raise ValueError(f"Source {i}: amplitude underflow; choose a less extreme partition")
        if not np.isfinite(amplitudes[i]).all() or np.max(np.abs(amplitudes[i])) >= bound:
            raise ValueError(f"Source {i}: amplitudes lie outside the requested open domain")
    ratios.setflags(write=False)
    amplitudes.setflags(write=False)
    return ratios, amplitudes
