"""Exact, fixed-partition density channels for the three particle sectors.

All coefficients are positive, UNNORMALIZED Green weights. Both one-body
and two-body channels are required to reconstruct the original Hamiltonian.
The one-body matrix is the original h; do not apply a second correction.
"""

from numbers import Integral

import numpy as np

from .models import (
    Channel, DensitySource, FixedDecomposition, OneBodyChannel,
    OneBodyDecomposition, PreparedProblem, TwoBodyDecomposition,
)
from .partitions import fixed_partition_amplitudes, positive_scale
from .prepare import select_sector_policy
from .validation import (
    _metric, _real_array, _require_report, validate_gauge_state,
)
from .models import ValidationReport


def _problem_policy(problem):
    if not isinstance(problem, PreparedProblem):
        raise TypeError("problem must be a PreparedProblem returned by prepare_problem/load_problem")
    _, policy = select_sector_policy(problem.nelec, problem.data.nbasis)
    if problem.policy != policy:
        raise ValueError("Problem policy is inconsistent with its particle numbers")
    return policy


def enumerate_sources(problem):
    """Fixed ordering, including zero couplings (no thresholds/deduplication).

    hybrid: bix then alpha<=beta; diagonal UD eq10, off-diagonal eq14 quartet.
    ab_only: bix then all ordered spatial (alpha,beta), always spins=(up,down).
    aa_only: bix then alpha<beta, spins=(up,up).
    """
    policy = _problem_policy(problem)
    r, n, _ = problem.data.chol.shape
    sources = []
    for g in range(r):
        for p in range(n):
            if policy == "ab_only":
                for q in range(n):
                    sources.append(DensitySource(g, (p,q), "eq10", (0,1)))
            elif policy == "aa_only":
                for q in range(p+1, n):
                    sources.append(DensitySource(g, (p,q), "eq10", (0,0)))
            else:
                for q in range(p, n):
                    sources.append(DensitySource(g, (p,q), "eq10" if p == q else "eq14",
                                                 (0,1) if p == q else None))
    return tuple(sources)


def build_two_body_channels(problem, gauge, tau2, t=None, *, partition="balanced_log",
                            amplitude_bound=1.0):
    """Build a reference two-body decomposition at a supplied validated gauge.

    t is indexed by enumerate_sources(problem), not by individual channels.
    One eq10 source emits two equal-weight +/- branches; an off-diagonal
    hybrid source emits a shared-amplitude four-spin quartet. The full state
    is validated here for reference correctness. Future inner-loss kernels
    should reuse validated state/source data rather than repeat ERI checks.
    """
    policy = _problem_policy(problem)
    tau2 = positive_scale(tau2, "tau2")
    validate_gauge_state(problem.data, gauge, problem.report.options)
    sources = enumerate_sources(problem)
    ratios, amplitudes = fixed_partition_amplitudes(
        gauge.eigenvalues, sources, tau2, t, partition, amplitude_bound)
    weight = 1.0 / tau2
    if not np.isfinite(weight) or weight <= 0:
        raise ValueError("tau2 gives a nonrepresentable positive channel coefficient")
    channels, slices = [], []
    for source, (left, right) in zip(sources, amplitudes):
        start = len(channels)
        if source.kind == "eq10":
            for sign in (1.0, -1.0):
                channels.append(Channel(source.bix, source.spins, weight/2,
                                        source.modes, (sign*left, sign*right)))
        else:
            for spins, sign in (((0,0),1.0), ((0,1),-1.0), ((1,0),-1.0), ((1,1),1.0)):
                channels.append(Channel(source.bix, spins, weight, source.modes,
                                        (sign*left, sign*right)))
        slices.append((start, len(channels)))
    return TwoBodyDecomposition(gauge, policy, problem.nelec, tau2, partition,
                                float(amplitude_bound), sources, ratios, amplitudes,
                                tuple(slices), tuple(channels))


def build_one_body_channels(problem, tau1):
    """Jointly diagonalize bare h and retain one channel per mode and spin.

    d=-epsilon*tau1, weight=1/tau1. Zero eigenvalues are retained as identity
    channels. Only up spin is emitted for aa_only. Real exponentials require
    d>-1; positive d>=1 is allowed because this identity has no minus branch.
    """
    policy = _problem_policy(problem)
    tau1 = positive_scale(tau1, "tau1")
    h = _real_array(problem.data.h1, "h1")
    n = problem.data.nbasis
    if h.shape != (n,n):
        raise ValueError("h1 must be square")
    _require_report(ValidationReport({"h1_symmetry": _metric(h, h.T, problem.report.options)},
                                     problem.report.options))
    ell, X = np.linalg.eigh(h)
    weight = 1.0 / tau1
    if not np.isfinite(weight) or weight <= 0:
        raise ValueError("tau1 gives a nonrepresentable positive coefficient")
    ds = -ell * tau1
    if not np.isfinite(ds).all() or np.any(1.0 + ds <= 0):
        raise ValueError("One-body amplitudes require 1-epsilon*tau1 > 0; choose smaller tau1")
    spins = (0,) if policy == "aa_only" else (0,1)
    channels = tuple(OneBodyChannel(s, weight, k, float(d))
                     for s in spins for k, d in enumerate(ds))
    ell.setflags(write=False)
    X.setflags(write=False)
    return OneBodyDecomposition(X, ell, tau1, channels)


def build_fixed_decomposition(problem, gauge, tau1, tau2, t=None, *,
                              partition="balanced_log", amplitude_bound=1.0):
    """Build both lists with the same policy, without normalizing either list."""
    two_body = build_two_body_channels(problem, gauge, tau2, t,
                                       partition=partition, amplitude_bound=amplitude_bound)
    one_body = build_one_body_channels(problem, tau1)
    result = FixedDecomposition(one_body, two_body)
    if not np.isfinite(result.denom) or result.denom <= 0:
        raise ValueError("The combined positive coefficient sum is not representable")
    return result


def two_body_rotation_matrix(channel, gauge):
    """Return [u_up,u_down], using None for an inactive identity spin block.

    Multiply actual rank-one factors in the stored order. This also retains
    the d_left*d_right term for a manually supplied repeated same-spin mode;
    generated step-2 channels never have repeated same-spin legs.
    """
    if not isinstance(channel, Channel):
        raise TypeError("channel must be a Channel")
    r, n, _ = gauge.X.shape
    if channel.bix >= r or any(p >= n for p in channel.modes):
        raise ValueError("Channel basis/mode index is out of range")
    U = [None, None]
    for spin, p, d in zip(channel.spins, channel.modes, channel.d):
        x = gauge.X[channel.bix, :, p]
        factor = np.eye(n) + d * np.outer(x, x)
        U[spin] = factor if U[spin] is None else U[spin] @ factor
    return U


def one_body_rotation_matrix(channel, one_body):
    """Single rank-one factor in the jointly diagonalized h eigenbasis."""
    n = one_body.X.shape[0]
    if channel.spin not in (0,1) or not 0 <= channel.mode < n:
        raise ValueError("Invalid one-body channel index")
    x = one_body.X[:, channel.mode]
    U = [None, None]
    U[channel.spin] = np.eye(n) + channel.d * np.outer(x, x)
    return U


def get_rotation_matrix(decomposition, index):
    """Index the combined list: one-body first, then two-body channels."""
    if isinstance(index, (bool, np.bool_)) or not isinstance(index, Integral):
        raise TypeError("Channel index must be an integer")
    if not 0 <= index < decomposition.nterms:
        raise IndexError("Channel index is out of range")
    n_one = len(decomposition.one_body.channels)
    if index < n_one:
        return one_body_rotation_matrix(decomposition.one_body.channels[index],
                                         decomposition.one_body)
    return two_body_rotation_matrix(decomposition.two_body.channels[index-n_one],
                                     decomposition.two_body.gauge)
