# Cholesky optimization: steps 1 through 3

This package implements input models, HDF5 loading, orthogonal Cholesky gauges,
factor diagonalization, deterministic identity checks, and fixed-partition
density-channel construction, and dense/overlap commutator-loss evaluation.
It does not yet optimize partitions/gauges or modify `sor_base.py`.

The package lives at `ipie/hamiltonians/optimize_cholesky/`. Run the examples
and tests from the ipie repository root, or with ipie installed. Imports start
with `ipie.hamiltonians.optimize_cholesky`.
Install NumPy and SciPy; also install h5py for HDF5 loading:

```sh
python -m pip install numpy scipy h5py
```

## Exact input conventions

| Tensor | Shape | Meaning |
| --- | --- | --- |
| `h1` | `(n,n)` | Bare/original physical one-body matrix h, **not h'** |
| `eri` | `(n,n,n,n)` | `eri[p,r,q,s] = (pr|qs)` |
| `chol` | `(r,n,n)` | `chol[gamma,p,r]`, with `eri = einsum('gpr,gqs->prqs', chol, chol)` |

Require n>=1 and r>=1; zero-valued factors are allowed. Arrays must be real,
finite, and compatible in shape. h and every Cholesky
matrix must be symmetric within the explicit validation tolerance. Complex
dtypes are rejected even if their imaginary part is zero. Flattened/packed
or transposed storage formats are not guessed: reshape/convert them explicitly
before calling `prepare_problem` if needed. No tensor is symmetrized, fitted,
truncated, or given a normal-order correction here.

## Load HDF5 and evaluate a gauge

For one file containing datasets `h1`, `eri`, and `chol`:

```python
import numpy as np
from ipie.hamiltonians.optimize_cholesky import (
    ValidationOptions, load_problem, exponential_gauge,
    givens_gauge, build_gauge_state,
)

options = ValidationOptions(atol=1e-12, rtol=1e-10, block_size=16)
problem = load_problem("integrals.h5", nelec=(1, 1), options=options)
initial = build_gauge_state(problem.data, options=options)  # O = identity

r = problem.data.nchol
theta = np.zeros(r * (r - 1) // 2)
if theta.size:
    theta[0] = 0.2
O = exponential_gauge(theta, r)
state = build_gauge_state(problem.data, O, options)

print(problem.policy)                 # ab_only for (1,1)
print(state.chol.shape)               # (r,n,n)
print(state.eigenvalues.shape)        # (r,n)
print(state.X.shape)                  # (r,n,n)
print(state.diagnostics.as_dict())    # absolute/relative errors and tolerances

# Alternative: a sequence of left-multiplied Givens rotations, angles in radians.
if r >= 2:
    O_givens = givens_gauge(r, [(0, 1, 0.2)])
    givens_state = build_gauge_state(problem.data, O_givens, options)
```

The files and dataset names are independently configurable:

```python
problem = load_problem(
    "h.h5", "eri.h5", "chol.h5",
    h1_key="integrals/h", eri_key="integrals/prqs", chol_key="factorization/L",
    nelec=(2, 0), options=options,
)
```

`eri_path` and `chol_path` default to `h1_path`. Keys can contain HDF5 group
paths. The loader opens files read-only and closes them before returning. It
loads full tensors into RAM; it is not an out-of-core loader. Preparation owns
read-only float64 copies, so peak memory includes the loaded tensors and their
prepared copies. In-memory data can instead be passed to
`prepare_problem(h1, eri, chol, nelec=..., options=...)`.

`nelec` is optional at this step. Without it the policy is `hybrid`; `(1,1)`
selects `ab_only`, and `N_down=0` selects `aa_only`. Counts are not guessed from
HDF5 datasets. Preparation records the policy; step-2 channel builders use that policy to
generate the appropriate spin products. The original h remains unchanged.

## Gauge and eigenvector conventions

- Exponential coordinates use `O = expm(S(theta)) @ reference`, with reference
  equal to identity by default. The strict upper triangle is packed in order
  `(0,1), (0,2), ..., (1,2), ...`; `S[p,q]=theta[k]`, `S[q,p]=-theta[k]`.
- `givens_gauge(r, [(p,q,angle), ...])` requires `p<q`. Its active block is
  `[[cos(angle), sin(angle)], [-sin(angle), cos(angle)]]`. Each rotation
  left-multiplies the current O in the supplied sequence; the last is leftmost.
- Mixing is `rotated[eta,p,r] = sum_gamma O[eta,gamma]*chol[gamma,p,r]`.
- A supplied orthogonal reference may have determinant -1. Neither validation
  nor rotation assumes determinant +1. The exponential map stays in the
  reference's determinant component.
- `state.X[gamma,p,alpha]` stores eigenvectors in columns. Eigenvalues are
  ascending. Reconstruction is
  `einsum('gpa,ga,gra->gpr', state.X, state.eigenvalues, state.X)`.
- All modes and factors, including zero or repeated ones, are retained.
  Eigenvector signs and bases within degenerate eigenspaces are not unique;
  tests compare reconstructed matrices, not arbitrary eigenvectors.

## Validation

`validate_inputs` and `validate_gauge_state` return a `ValidationReport` on
success and raise `ValidationError`, a `ValueError` subclass, on numerical
failure. The exception's `report` contains numerical metrics when available.
Malformed arrays fail before these matrix metrics can be constructed.

Acceptance for a numerical identity is
`max_abs_error <= atol + rtol * reference_max_abs`. Each factor gets its own
scale for symmetry and eigenpair reconstruction; a large factor cannot hide
an asymmetric small factor. Relative Frobenius errors are also recorded.
For zero reference norm the relative diagnostic is 0 for exact agreement,
otherwise `None`; absolute error determines acceptance.

The checks include:

1. Original h/factor symmetry and exact recovery of supplied ERIs.
2. Orthogonality of O, including reflections.
3. Agreement with the specified rotation, retaining (r,n,n).
4. `X.T @ X = I` and eigenpair reconstruction for every factor.
5. Rotated-factor recovery of supplied ERIs and direct ERI gauge invariance.
6. Invariance of `sum_gamma L_gamma @ L_gamma` (matrix products).

Every ERI element is checked. Using `C = chol.reshape(r,n*n)`, each comparison
evaluates row blocks of `C.T @ C`, avoiding an additional full n^4 reconstruction.
`block_size` controls the number of pair rows per block. This still requires
full ERI input storage and O(r*n^4) arithmetic per full comparison. Full checks
are appropriate at initialization and for reference/final verification, not
inside every future optimizer loss evaluation. Low-level `rotate_cholesky`
and `diagonalize_factors` do not reconstruct ERIs.

Defaults assume float64-quality exact data. If tensors were stored in float32,
explicitly choose tolerances matching that precision; converting to float64
does not recover lost digits. Never loosen tolerances to mask an index-order
or physical-convention error.

## Channel contract

`Channel(bix, spins, a_i, modes, d)` has exactly the requested fields:

```python
from ipie.hamiltonians.optimize_cholesky import Channel
channel = Channel(
    bix=0, spins=(0, 1), a_i=5.0, modes=(2, 1), d=(0.1, -0.2)
)
```

`bix` indexes the **final** Cholesky eigenbasis, 0=up and 1=down; `d` contains
actual branch amplitudes, and `a_i` is the positive **unnormalized** coefficient
in Lambda*I-H. All four spin orientations are representable. A future adapter
can canonicalize `(1,0)` to `(0,1)` by swapping both legs, since opposite spins
commute. The step-2 builders enforce source enumeration, paired-domain constraints,
and branch sharing. The loader and gauge builder themselves still emit no
channels; call the channel builders described below.

The `GaugeState` object is the completed output of step 1. It holds owned
read-only arrays and diagnostics, with no optimizer backend or open HDF5
handle. A final optimized/channel result and its persistence will be added
later; the present state does not imply optimization has occurred.

## Run tests

From the ipie repository root:

```sh
python -m unittest discover -s ipie/hamiltonians/optimize_cholesky/tests -v
```

The tests use independent dense contractions and temporary HDF5 files,
including custom dataset paths and separate input files.
When h5py is missing, the three actual HDF5 tests are explicitly skipped;
they execute normally after installing h5py. The array-only functions do not
import h5py. The present implementation is a NumPy/SciPy reference; a later
automatic-differentiation implementation must preserve these conventions
without passing differentiable tensors through NumPy conversions.

## Step 2: fixed partitions and density channels

```python
import numpy as np
from ipie.hamiltonians.optimize_cholesky import (
    load_problem, build_gauge_state, enumerate_sources,
    build_fixed_decomposition, build_two_body_channels, get_rotation_matrix,
)

problem = load_problem("integrals.h5", nelec=(1, 1))
gauge = build_gauge_state(problem.data)  # or use a step-1 rotated gauge
sources = enumerate_sources(problem)
t = np.zeros(len(sources))
decomposition = build_fixed_decomposition(
    problem, gauge, tau1=0.01, tau2=0.01, t=t,
    partition="balanced_log",
)

# Keep these two lists separate for the future sor_base adapter.
two_body_channels = decomposition.two_body.channels
one_body_channels = decomposition.one_body.channels
print(two_body_channels[:2])  # bix, spins, a_i, modes, actual signed d
print(decomposition.denom)    # sum of all UNNORMALIZED coefficients
U_up, U_down = get_rotation_matrix(decomposition, 0)
```

Choose the fixed positive scales small enough that all amplitudes are admissible.
There is no automatic rescaling or clipping. If only the two-body list is wanted,
call `build_two_body_channels(problem, gauge, tau2, t=...)`.
One-body channels can be built separately with
`build_one_body_channels(problem, tau1)`.

### Sources and spin policies

One entry in `sources` owns one ratio. Its two Eq. (10) branches or its four
Eq. (14) hybrid branches share that ratio. `source_slices[i]` gives the
half-open interval of **two-body** channels emitted by source i.
The order is fixed, including exactly zero couplings:

| Policy | Source order within each bix | N_source | N_two_body | Sum of two-body weights |
| --- | --- | --- | --- | --- |
| `hybrid` | alpha<=beta; diagonal UD two-branch, off-diagonal quartet | r*n*(n+1)/2 | 2*r*n*n | r*(2*n*n-n)/tau2 |
| `ab_only` | all ordered spatial (alpha,beta), always spins=(0,1) | r*n*n | 2*r*n*n | r*n*n/tau2 |
| `aa_only` | alpha<beta, spins=(0,0) | r*n*(n-1)/2 | r*n*(n-1) | r*n*(n-1)/(2*tau2) |

Hybrid quartets are emitted as (UU,UD,DU,DD), with common leg signs
(+,-,-,+), and each channel weight 1/tau2. Every Eq. (10) product emits the
+ branch followed by the - branch, each with weight 1/(2*tau2). Quartet
amplitudes cannot be assigned independent spin-channel ratios under this
identity. Different two-branch sources may have independent ratios.

`hybrid` is a full-Fock-space identity; `ab_only` is used only for (1,1),
and `aa_only` only for N_down=0. The builders reject a policy inconsistent
with the PreparedProblem particle counts. If particle counts are absent,
the generic hybrid policy is used. Fully spin-up systems with <=1 electron
still retain the formal source list; its two-body action vanishes on that
sector. No topology changes are made based on the sector or coupling size.

### Two partition maps

The finite scalar or vector `t` is a **fixed log ratio**, not a bounded z
coordinate and not an optimizer input. A scalar broadcasts to all sources;
`None` means zero. Let ell_L,ell_R be the source's two Cholesky eigenvalues.

- `balanced_log` (default): with k=abs(ell_L*ell_R*tau2),
  d_L=sign(ell_L)*sqrt(k)*exp(t),
  d_R=-sign(ell_R)*sqrt(k)*exp(-t).
  If either eigenvalue is zero, both amplitudes are defined to be zero.
- `anchored_log`: d_L=ell_L*sqrt(tau2)*exp(t),
  d_R=-ell_R*sqrt(tau2)*exp(-t).
  At zero coupling one leg may survive. The complete source still cancels
  correctly; these channels are not silently replaced by identities.

Both maps enforce d_L*d_R=-W*tau2 and use analytic constant weights even at
W=0. Both signs of each leg occur, so require abs(d)<amplitude_bound<=1.
The default bound is 1; supply a smaller positive bound for a safety margin.
Large fixed ratios or scales that violate the open domain raise ValueError.
Amplitudes are evaluated in logarithmic form to avoid gratuitous overflow.

`TwoBodyDecomposition` holds the gauge, policy, particle counts, scales,
source table, fixed ratios, base amplitudes, source slices, and channel tuple.
These metadata preserve the ownership needed by the future partition solver.
No optimizer or automatic differentiation is implemented at this step.

### One-body terms and normalization

The one-body matrix is the original physical h, which is jointly diagonalized
once. One channel per mode and retained spin has d=-epsilon*tau1 and weight
1/tau1. Both spins are retained for hybrid/ab_only; only up spin for aa_only.
Zero one-body eigenvalues are retained as identity channels. For these single
branches the actual real-exponential condition is d>-1; positive d>=1 is valid.

`FixedDecomposition` contains `one_body` and `two_body`. Its combined order is
one-body channels followed by two-body channels. `coefficients` is the raw
positive array; `denom` is their common sum B. The matrix helpers return
[u_up,u_down], with None for an inactive identity block, matching sor_test.py.
They multiply the stored rank-one factors literally, including any repeated
same-spin cross term in a manually constructed channel.

For E0=0, H=B*I-sum_i a_i*U_i. For an external scalar E0, Lambda=E0+B and
Lambda*I-H=sum_i a_i*U_i. Divide the **combined** raw sum by B when checking
the normalized Green function. Do not normalize the two lists separately.
Full two-body and one-body reconstruction is exact in the policy's stated
space, up to floating-point error and the input-validation tolerance.

### Step-2 reference tests

```sh
python -m unittest discover -s ipie/hamiltonians/optimize_cholesky/tests -v
python -m ipie.hamiltonians.optimize_cholesky.tests.test_channels
```

The second command prints readable H/G/Slater residuals and runs the new tests.
Like `ipie/hamiltonians/tests/sor_test.py`, the tests use interleaved bitstrings,
`string_act` fermionic signs, determinant minors to lift rotations, and Slater
determinant coefficients. The reference Hamiltonian is independently built
from **bare h plus the canonical quartic ERI operator**; no extra normal-order
correction is subtracted in that reference. Tests check H, shifted raw G,
normalized G, individual density-factor actions, and action on a general
Slater determinant. Hybrid is also tested on full Fock space. Reduced policies
are tested in their physical sectors and explicitly shown to fail outside them.

Additional cases cover both partition maps, both signs of W, shared quartet
ratios, known channel/weight counts, rotated gauges, diagonal opposite spins,
zero couplings, a valid one-body d>1, empty two-body lists, and invalid domains.
Their numerical checks use NumPy/SciPy and the existing pure-Python
bitstring_utils. They do not call HDF5 I/O, PySCF, or sor_base construction.
Importing the full ipie package may still require its installed runtime
dependencies. The test module adds no new dependency beyond step 1.

## Step 3: reference commutator loss

```python
from ipie.hamiltonians.optimize_cholesky import (
    load_problem, build_gauge_state, build_fixed_decomposition,
    commutator_loss, raw_loss, OverlapEvaluator,
)

problem = load_problem("integrals.h5", nelec=(1, 1))
gauge = build_gauge_state(problem.data)
decomposition = build_fixed_decomposition(problem, gauge, .01, .01, t=0.0)

dense = commutator_loss(decomposition, method="dense")
fast = commutator_loss(decomposition, method="overlap")
print(dense.comm2, fast.comm2)
print(fast.as_dict())
loss = raw_loss(decomposition)  # unweighted squared objective only

# Reuse a fixed-state cache for pair-by-pair inspection.
evaluator = OverlapEvaluator(decomposition)
pair_squared_norm = evaluator.pair_norm2(0, 1)
same_total = evaluator.evaluate()
```

`commutator_loss` defaults to `method="overlap"`. Convenience functions
`dense_commutator_loss` and `overlap_commutator_loss` return the same result
type. All methods include both the one-body and two-body channel lists in
their existing combined order. They evaluate real float64 single-particle
matrices, not many-body Fock-space commutators.

### Exact agreement with compute_total_commutativity

For each unordered pair i<j, define

```
pair_ij = ||[u_i_up,u_j_up]||_F**2 + ||[u_i_down,u_j_down]||_F**2
```

`None` means identity in an inactive spin block. Squared spin norms are
added; there is no square root. The returned `CommutatorLoss` fields map to
`sor_base.compute_total_commutativity` as follows:

| Returned field | Existing printed diagnostic |
| --- | --- |
| `comm2` | `comm2` = sum(pair_ij) = L_raw |
| `weighted_comm2` | sum(a[i]*a[j]*pair_ij) |
| `weight` | sum(a[i]*a[j]) over **all** i<j |
| `weighted_mean` | `weighted_comm2/weight` |
| `pair_count` | nterms*(nterms-1)/2, including commuting/identity pairs |
| `weights_normalized` | Whether a[i] is the raw coefficient divided by denom |

By default, `normalize_weights=True`: a[i]=coefficient[i]/decomposition.denom.
This matches a parsed SumOfRotationBase object. To compare with raw coefficients,
pass `normalize_weights=False`. A common coefficient rescaling leaves comm2
and weighted_mean unchanged; it rescales the raw weighted numerator and
denominator by the square of that factor. The unweighted comm2 alone is the
optimization objective; weighted fields are diagnostics.

The comparison requires the same actual channels, partitions, and coefficient
convention. Fock-space equality of two Hamiltonian decompositions does not
guarantee equal L_raw. Identity channels contribute zero commutators but still
contribute to the weighted denominator. Retained anchored zero-coupling sources
can have nonidentity channels, even though their Hamiltonian source sum is zero.
No channels are coalesced or deleted by the objective evaluator.

For fewer than two channels the pair sum is empty: comm2=weighted_comm2=weight=0
and weighted_mean=None. This explicitly represents an undefined weighted mean;
the existing print-only sor_base function divides by zero in this case.

### Overlap formula and spin blocks

Within each spin sector write the channel increment as A=V D V.T, where the
active columns of V belong to one orthonormal h or Cholesky eigenbasis.
Each generated block has at most two active columns. For another increment
B=Z E Z.T and C=V.T @ Z, the public kernel `commutator_norm2(d,e,C)` uses

```
||[A,B]||_F**2 = 2*Tr(D**2 @ C @ E**2 @ C.T)
                 - 2*Tr((D @ C @ E @ C.T) @ (D @ C @ E @ C.T))
```

Here D=diag(d), E=diag(e); the final matrix square is an ordinary matrix
product. It is not an elementwise square or a squared Frobenius norm.

`OverlapEvaluator` builds actual signed spin blocks from the stored channels.
It preserves (down,up) leg assignments, rather than treating all opposite-spin
channels as having the same spatial ordering. Repeated same-spin modes are
merged using kappa_new=kappa_old+d+kappa_old*d. Distinct modes in one basis
are orthogonal, so no cross term survives between them. Zero increments
can be skipped without deleting the channel itself.

Disjoint-spin blocks, one-body/one-body pairs in the joint h basis, and
same-Cholesky-basis pairs commute structurally. Their zero contribution is
skipped in the numerator, while their coefficient pair remains in `weight`.
Other pairs use lazily cached Q.T@X_gamma or X_gamma.T@X_eta overlaps, with
only small selected submatrices passed to the norm kernel. No dense channel
matrices or commutators are constructed by the overlap evaluator.

All bases must have orthonormal columns. Tiny negative squared norms relative
to the computed terms are clamped to zero; materially negative values raise
FloatingPointError. This is a roundoff safeguard, not a replacement for valid
overlaps. Near commuting pairs, use absolute as well as relative comparisons
against the dense reference.

The cache is bound to a fixed decomposition and owns snapshots of the bases.
Create a new evaluator when the gauge, amplitudes, or channel list changes.
The reference evaluator still visits O(N_channels**2) unordered pairs. Its
lazy basis-overlap cache can grow to O(r**2*n**2) storage; it does not promise
cheap full objectives merely because individual blocks have low rank.
There is no autodifferentiation, stochastic pair sampling, or partition
optimization at this stage.

### Run the step-3 comparisons

```sh
python -m unittest discover -s ipie/hamiltonians/optimize_cholesky/tests -v
python -m ipie.hamiltonians.optimize_cholesky.tests.test_objective
```

The direct module command prints dense, overlap, and sor_base losses for the
three policies, then runs the new tests. The tests AST-load the **actual**
compute_total_commutativity function from the checked-out sor_base.py,
unchanged, and capture its printed diagnostics. A read-only view supplies
exactly the same channel matrices and coefficients. This avoids unrelated
SOR construction/import dependencies while testing the requested reference
function itself. It is not a replacement copy of that function.

Additional tests cover every channel pair, both partition maps, rotated and
identity gauges, signed low-rank coefficients, both spin contributions,
opposite-spin leg ordering, repeated modes, zero sources, one-channel edge
cases, raw/normalized weights, coefficient rescaling, invalid overlaps, and
negative-roundoff handling. The overlap path is also tested with dense channel
construction disabled. The stale step-1 test import has been updated from
the removed gauge module to your merged prepare module.



