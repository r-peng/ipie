"""Fixed exponential objective and backwards-compatible L-BFGS convenience API.

The objective defines coordinates and nested partition relaxation. Search
directions, acceptance and curvature history belong to solver subclasses.
"""

from dataclasses import asdict, replace
import math

import numpy as np

from .derivatives import exponential_gauge_vjp
from .gradients import GaugeEvaluator
from .models import (
    ExponentialEvaluation, InnerConvergenceError, InnerOptions,
)
from .partitions import _partition_limits, _readonly
from .prepare import exponential_gauge
from .solvers.base import RECOVERABLE_TRIAL_ERRORS
from .solvers.lbfgs import LBFGSOptimizer, _coerce_lbfgs_options
from .validation import _real_array, validate_gauge_state


_TRIAL_ERRORS = RECOVERABLE_TRIAL_ERRORS


class ExponentialGaugeObjective:
    """Reduced value/gradient oracle with one immutable coordinate reference.

    The inner configuration and supplied seed are frozen for a run. With no
    seed, every trial starts at its own interval midpoints. A rejected trial
    never becomes the seed for another evaluation. The one-entry cache holds
    theta, value, gradient and inner solution together; no unbounded snapshot
    history is retained. General inner solutions are tracked local solutions,
    not certified global minima.
    """

    def __init__(self,evaluator,*,reference=None,inner_options=None,inner_t0=None):
        if not isinstance(evaluator,GaugeEvaluator):
            raise TypeError("evaluator must be a GaugeEvaluator")
        self._evaluator = evaluator
        self._nchol = evaluator.problem.data.nchol
        self._nparams = self.nchol*(self.nchol-1)//2
        if inner_options is not None and not isinstance(inner_options,InnerOptions):
            raise TypeError("inner_options must be InnerOptions")
        self._inner_options = InnerOptions() if inner_options is None else inner_options
        _partition_limits(evaluator.amplitude_bound,self.inner_options.amplitude_limit,
                          self.inner_options.max_abs_t)
        self._reference = _readonly(exponential_gauge(np.zeros(self.nparams),self.nchol,reference))
        if inner_t0 is None:
            self._inner_t0 = None
        else:
            seed = _real_array(inner_t0,"inner_t0")
            if seed.ndim != 0 and seed.shape != (len(evaluator.sources),):
                raise ValueError("inner_t0 must be a scalar or have one entry per source")
            self._inner_t0 = _readonly(seed)
        self.evaluations = self.failed_evaluations = self.cache_hits = self.inner_sweeps = 0
        self._cached = None

    @property
    def evaluator(self):
        return self._evaluator

    @property
    def nchol(self):
        return self._nchol

    @property
    def nparams(self):
        return self._nparams

    @property
    def inner_options(self):
        return self._inner_options

    @property
    def reference(self):
        return self._reference

    @property
    def inner_t0(self):
        return self._inner_t0

    def evaluate(self,theta):
        """Return one matching value/coordinate-gradient/inner snapshot."""
        theta = _real_array(theta,"theta")
        if theta.shape != (self.nparams,):
            raise ValueError(f"theta must be a length-{self.nparams} vector")
        if self._cached is not None and np.array_equal(theta,self._cached.theta):
            self.cache_hits += 1
            return self._cached
        self.evaluations += 1
        inner = None
        try:
            O = exponential_gauge(theta,self.nchol,self.reference)
            derivative = self.evaluator.relaxed(O,t0=self.inner_t0,**asdict(self.inner_options))
            inner = derivative.inner_result
            if inner is None or not inner.converged:
                raise InnerConvergenceError("Outer objective requires a converged inner snapshot",inner)
            gradient = exponential_gauge_vjp(theta,self.nchol,derivative.gradient_O,
                                              self.reference,backend=self.evaluator.backend)
            if (not np.isfinite(derivative.loss) or not np.isfinite(gradient).all()
                    or not np.isfinite(derivative.tangent_gradient).all()):
                raise FloatingPointError("Nonfinite outer value or coordinate gradient")
            point = ExponentialEvaluation(_readonly(theta),_readonly(gradient),derivative)
            if not math.isfinite(point.tangent_gradient_norm):
                raise FloatingPointError("Nonfinite physical tangent-gradient norm")
        except _TRIAL_ERRORS as exc:
            self.failed_evaluations += 1
            if inner is None:
                inner = getattr(exc,"inner_result",None)
            if inner is None and isinstance(exc,InnerConvergenceError):
                inner = exc.result
            if inner is not None:
                self.inner_sweeps += inner.sweeps
            raise
        self.inner_sweeps += inner.sweeps
        self._cached = point
        return point

    def value_and_grad(self,theta):
        """Joint callable for external optimizers, e.g. a SciPy jac=True call."""
        point = self.evaluate(theta)
        return point.loss,point.gradient_theta.copy()

    def validate(self,point):
        """Full final gauge/ERI check, called outside the optimizer loops."""
        return validate_gauge_state(
            self.evaluator.problem.data,point.decomposition.two_body.gauge,
            self.evaluator.problem.report.options)


def _minimize_exponential(objective,theta0,options,callback=None):
    """Legacy private driver; final validation remains the caller's responsibility.

    Kept for the step-6 controlled tests and existing private callers. New
    code should construct LBFGSOptimizer and use optimize() directly.
    """
    options = replace(_coerce_lbfgs_options(options),validate_final=False)
    return LBFGSOptimizer(objective,options=options).optimize(theta0,callback=callback)


def optimize_gauge(evaluator,*,theta0=None,reference=None,inner_t0=None,
                    inner_options=None,options=None,callback=None):
    """Convenience wrapper for fixed-exponential L-BFGS with nested relaxation.

    New code can construct ExponentialGaugeObjective and LBFGSOptimizer
    explicitly. options accepts LBFGSOptions, common OptimizerOptions or the
    legacy OuterOptions. Other solvers have their own subclasses and do not
    pass through this L-BFGS-specific convenience function.

    callback(record) receives initial/accepted scalar diagnostics. Raising
    StopIteration returns that accepted state with status='callback_stopped'.
    Final full gauge/ERI validation is run once by default, outside the loops.
    """
    options = _coerce_lbfgs_options(options)
    objective = ExponentialGaugeObjective(evaluator,reference=reference,
                                          inner_options=inner_options,inner_t0=inner_t0)
    return LBFGSOptimizer(objective,options=options).optimize(theta0,callback=callback)
