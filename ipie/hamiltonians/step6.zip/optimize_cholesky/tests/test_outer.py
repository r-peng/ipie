"""Nested outer solves with real Hamiltonian, gradient and failure checks."""

from dataclasses import FrozenInstanceError
import math
import unittest
from unittest.mock import patch

import numpy as np

from ipie.hamiltonians.optimize_cholesky import (
    ExponentialGaugeObjective, GaugeEvaluator, GaugeFeasibilityError,
    GaugeRegularityError, InnerConvergenceError, InnerOptions, OuterOptions,
    exponential_gauge, exponential_gauge_vjp, optimize_gauge, prepare_problem, raw_loss,
)
from ipie.hamiltonians.optimize_cholesky.tests.test_channels import (
    check_hamiltonian, example_tensors, make_decomposition,
)


def engine_fixture(nelec=(2,0),partition="balanced_log"):
    problem,_ = make_decomposition(nelec,partition=partition)
    return problem,GaugeEvaluator(problem,tau1=.2,tau2=.04,partition=partition)


class NestedOracleTests(unittest.TestCase):
    def test_joint_cache_copies_seed_and_keeps_reference_and_configuration_fixed(self):
        problem,engine = engine_fixture()
        reference=np.diag([-1.,1.])@exponential_gauge([.1],2)
        seed=np.linspace(-.1,.1,len(engine.sources))
        saved=seed.copy()
        options=InnerOptions(gradient_atol=1e-12,gradient_rtol=0)
        objective=ExponentialGaugeObjective(engine,reference=reference,
                                            inner_options=options,inner_t0=seed)
        seed[:]=10
        np.testing.assert_array_equal(objective.inner_t0,saved)
        for name,value in (("inner_options",InnerOptions()),("reference",np.eye(2)),
                           ("inner_t0",None),("evaluator",engine),("nparams",99)):
            with self.subTest(name=name),self.assertRaises(AttributeError):
                setattr(objective,name,value)
        with self.assertRaises(FrozenInstanceError):
            options.max_sweeps=1
        theta=np.array([.03])
        point=objective.evaluate(theta)
        np.testing.assert_allclose(point.O,exponential_gauge(theta,2,reference),atol=1e-15)
        expected=exponential_gauge_vjp(theta,2,point.gauge_gradient.gradient_O,reference)
        np.testing.assert_array_equal(point.gradient_theta,expected)
        self.assertAlmostEqual(point.loss,raw_loss(point.decomposition,method="dense"),places=14)
        theta[0]=1.
        self.assertEqual(point.theta[0],.03)
        value,gradient=objective.value_and_grad([.03])
        self.assertEqual(objective.evaluations,1)
        self.assertEqual(objective.cache_hits,1)
        self.assertEqual(value,point.loss)
        gradient[:]=123
        np.testing.assert_array_equal(point.gradient_theta,expected)
        self.assertIs(objective.evaluate([.03]),point)
        self.assertFalse(objective.reference.flags.writeable)
        self.assertFalse(point.theta.flags.writeable)
        self.assertFalse(point.gradient_theta.flags.writeable)

    def test_relaxed_theta_gradient_rechecks_partitions_and_moving_bounds(self):
        _,engine=engine_fixture()
        reference=exponential_gauge([.37],2)
        state=engine.decomposition(reference)
        ell=state.two_body.gauge.eigenvalues
        rho=1.025*max(np.sqrt(abs(ell[s.bix,s.modes[0]]*ell[s.bix,s.modes[1]])*.04)
                       for s in engine.sources)
        objective=ExponentialGaugeObjective(
            engine,reference=reference,
            inner_options=InnerOptions(amplitude_limit=rho,gradient_atol=1e-12,gradient_rtol=0))
        calls=[]
        original=engine.relaxed
        def record(O,**kwargs):
            result=original(O,**kwargs)
            calls.append((O.copy(),result.decomposition.two_body.t.copy()))
            return result
        with patch.object(engine,"relaxed",side_effect=record):
            center=objective.evaluate([0.])
            plus=objective.evaluate([1e-6])
            minus=objective.evaluate([-1e-6])
        self.assertEqual(len(calls),3)
        self.assertTrue(all(not np.array_equal(calls[0][0],item[0]) for item in calls[1:]))
        self.assertGreater(np.max(np.abs(calls[1][1]-calls[2][1])),1e-9)
        finite=(plus.loss-minus.loss)/2e-6
        np.testing.assert_allclose(center.gradient_theta[0],finite,atol=2e-10,rtol=3e-7)
        wrong=exponential_gauge_vjp([0.],2,center.gauge_gradient.fixed_gradient_O,reference)[0]
        self.assertGreater(abs(wrong-finite),1e-6)

    def test_post_inner_regularity_failure_retains_inner_work_diagnostics(self):
        _,engine=engine_fixture()
        objective=ExponentialGaugeObjective(engine)
        with patch("ipie.hamiltonians.optimize_cholesky.gradients.normalized_partition_gradient",
                   side_effect=GaugeRegularityError("injected post-inner failure")):
            with self.assertRaises(GaugeRegularityError) as context:
                objective.evaluate([0.])
        inner=context.exception.inner_result
        self.assertTrue(inner.converged)
        self.assertGreater(inner.sweeps,0)
        self.assertEqual(objective.inner_sweeps,inner.sweeps)
        self.assertEqual(objective.failed_evaluations,1)
        self.assertIsNone(objective._cached)

    def test_options_and_failed_initial_evaluations_are_not_hidden(self):
        _,engine=engine_fixture()
        for kwargs in ({"max_iterations":-1},{"max_evaluations":0},{"memory":0},
                       {"backtrack":1.},{"armijo":0.},{"gradient_atol":np.nan},
                       {"initial_step":0.},{"curvature_rtol":1.},{"validate_final":"yes"}):
            with self.subTest(kwargs=kwargs),self.assertRaises(ValueError):
                OuterOptions(**kwargs)
        for kwargs in ({"max_sweeps":True},{"gradient_atol":-1},{"amplitude_limit":1.},
                       {"max_abs_t":0.}):
            with self.subTest(kwargs=kwargs),self.assertRaises(ValueError):
                InnerOptions(**kwargs)
        with self.assertRaises(TypeError):
            optimize_gauge(engine,options={})
        with self.assertRaises(TypeError):
            optimize_gauge(engine,inner_options={})
        with self.assertRaises(ValueError):
            optimize_gauge(engine,theta0=[0.,0.])
        with self.assertRaises(ValueError):
            optimize_gauge(engine,reference=np.zeros((2,2)))
        with self.assertRaises(InnerConvergenceError):
            optimize_gauge(engine,inner_options=InnerOptions(max_sweeps=0))
        with self.assertRaises(GaugeFeasibilityError):
            optimize_gauge(engine,inner_options=InnerOptions(amplitude_limit=.001))


class PhysicalOuterTests(unittest.TestCase):
    def test_nontrivial_physical_descent_reaches_a_smooth_stationary_region(self):
        # Commuting factors but a noncommuting h. A rotation from the mixed
        # definite/indefinite region enters a smooth constant-minimum region.
        h=np.array([[.2,.13],[.13,-.1]])
        chol=np.array([np.diag([1.3,.7]),np.diag([.7,-.5])])
        eri=np.einsum("gpr,gqs->prqs",chol,chol)
        problem=prepare_problem(h,eri,chol,nelec=(1,1))
        engine=GaugeEvaluator(problem,tau1=.2,tau2=.04)
        result=optimize_gauge(engine,options=OuterOptions(max_iterations=10,max_step_norm=.5))
        self.assertTrue(result.converged)
        self.assertGreater(result.iterations,0)
        self.assertLess(result.loss,.9*result.initial_loss)
        self.assertLessEqual(result.gradient_norm,result.gradient_threshold)
        self.assertLessEqual(result.tangent_gradient_norm,result.tangent_gradient_threshold)
        self.assertTrue(result.validation_report.passed)
        check_hamiltonian(result.decomposition,h,eri,(1,1))

    def test_nested_descent_reconstruction_and_final_snapshot_all_policies_and_maps(self):
        for nelec in ((2,0),(2,1),(1,1)):
            for partition in ("balanced_log","anchored_log"):
                with self.subTest(nelec=nelec,partition=partition):
                    problem,engine=engine_fixture(nelec,partition)
                    callback_rows=[]
                    result=optimize_gauge(
                        engine,options=OuterOptions(max_iterations=3,max_step_norm=.3),
                        inner_options=InnerOptions(gradient_atol=1e-12,gradient_rtol=0),
                        callback=callback_rows.append)
                    self.assertLess(result.loss,result.initial_loss)
                    self.assertTrue(np.all(np.diff([row.loss for row in result.history])<=0))
                    self.assertEqual(tuple(callback_rows),result.history)
                    self.assertTrue(result.validation_report.passed)
                    self.assertTrue(result.partition_result.converged)
                    np.testing.assert_allclose(result.loss,raw_loss(result.decomposition,method="dense"),
                                               atol=3e-17,rtol=3e-11)
                    np.testing.assert_allclose(result.O,exponential_gauge(result.theta,2,result.reference),atol=1e-15)
                    expected=exponential_gauge_vjp(result.theta,2,result.evaluation.gauge_gradient.gradient_O,
                                                   result.reference)
                    np.testing.assert_array_equal(result.gradient_theta,expected)
                    check_hamiltonian(result.decomposition,problem.data.h1,problem.data.eri,nelec)
                    self.assertEqual(len(result.history),result.iterations+1)
                    self.assertFalse(result.theta.flags.writeable)
                    self.assertFalse(result.reference.flags.writeable)
                    if result.converged:
                        self.assertLessEqual(result.gradient_norm,result.gradient_threshold)
                        self.assertLessEqual(result.tangent_gradient_norm,result.tangent_gradient_threshold)

    def test_recoverable_trials_backtrack_and_preserve_the_frozen_seed(self):
        _,engine=engine_fixture()
        original=engine.relaxed
        calls=[]
        seed=np.linspace(-.15,.15,len(engine.sources))
        def reject_large(O,**kwargs):
            calls.append((O.copy(),kwargs["t0"].copy()))
            if np.linalg.norm(O-np.eye(2))>.11:
                raise InnerConvergenceError("injected large-step inner failure")
            return original(O,**kwargs)
        with patch.object(engine,"relaxed",side_effect=reject_large):
            result=optimize_gauge(engine,inner_t0=seed,
                                   options=OuterOptions(max_iterations=1,max_step_norm=.4))
        self.assertGreater(result.failed_evaluations,0)
        self.assertTrue(any("InnerConvergenceError" in row.reason for row in result.trials))
        self.assertEqual(result.iterations,1)
        self.assertLess(result.loss,result.initial_loss)
        self.assertLessEqual(np.linalg.norm(result.O-np.eye(2)),.11)
        for _,supplied_seed in calls:
            np.testing.assert_array_equal(supplied_seed,seed)

    def test_failed_line_search_returns_accepted_state_not_last_trial(self):
        _,engine=engine_fixture()
        original=engine.relaxed
        count=0
        def reject_all_trials(O,**kwargs):
            nonlocal count
            count+=1
            if count>1:
                raise GaugeRegularityError("injected rejected trial")
            return original(O,**kwargs)
        with patch.object(engine,"relaxed",side_effect=reject_all_trials):
            result=optimize_gauge(engine,options=OuterOptions(max_iterations=2,max_line_search=3))
        self.assertFalse(result.converged)
        self.assertEqual(result.status,"line_search_failed")
        self.assertEqual(result.iterations,0)
        self.assertEqual(result.evaluations,4)
        self.assertEqual(result.failed_evaluations,3)
        self.assertEqual(result.loss,result.initial_loss)
        np.testing.assert_array_equal(result.theta,[0.])
        np.testing.assert_array_equal(result.O,np.eye(2))
        self.assertTrue(result.validation_report.passed)

    def test_two_orbital_shortcut_has_zero_inner_sweeps_during_nontrivial_descent(self):
        h,_,chol=example_tensors(n=2,r=2,seed=37)
        chol[0]+=.8*np.eye(2)
        eri=np.einsum("gpr,gqs->prqs",chol,chol)
        problem=prepare_problem(h,eri,chol,nelec=(1,1))
        engine=GaugeEvaluator(problem,tau1=.2,tau2=.04)
        result=optimize_gauge(engine,options=OuterOptions(max_iterations=3))
        self.assertLess(result.loss,.9*result.initial_loss)
        self.assertTrue(all(row.inner_sweeps==0 for row in result.history))
        check_hamiltonian(result.decomposition,h,eri,(1,1))

    def test_physical_stationarity_is_checked_at_a_singular_exponential_chart(self):
        h,eri,chol=example_tensors(n=3,r=3,seed=29)
        problem=prepare_problem(h,eri,chol,nelec=(2,1))
        engine=GaugeEvaluator(problem,tau1=.2,tau2=.04)
        objective=ExponentialGaugeObjective(engine)
        center=objective.evaluate(np.zeros(3))
        axis=np.cross(center.gradient_theta,[1.,0.,0.])
        if np.linalg.norm(axis)<1e-14:
            axis=np.cross(center.gradient_theta,[0.,1.,0.])
        theta=2*math.pi*axis/np.linalg.norm(axis)
        result=optimize_gauge(engine,theta0=theta,
                               options=OuterOptions(max_iterations=3,gradient_atol=1e-9,gradient_rtol=0))
        self.assertFalse(result.converged)
        self.assertEqual(result.status,"coordinate_stalled")
        self.assertEqual(result.iterations,0)
        self.assertLess(result.gradient_norm,1e-9)
        self.assertGreater(result.tangent_gradient_norm,1e-6)
        np.testing.assert_array_equal(result.theta,theta)
        np.testing.assert_array_equal(result.reference,np.eye(3))

    def test_single_factor_has_no_continuous_gauge_parameters(self):
        h=np.array([[.2,.1],[.1,-.1]])
        chol=np.array([np.diag([-.3,.7])])
        eri=np.einsum("gpr,gqs->prqs",chol,chol)
        problem=prepare_problem(h,eri,chol,nelec=(1,1))
        engine=GaugeEvaluator(problem,tau1=.1,tau2=.04)
        result=optimize_gauge(engine,reference=[[-1.]])
        self.assertTrue(result.converged)
        self.assertEqual(result.iterations,0)
        self.assertEqual(result.evaluations,1)
        self.assertEqual(result.theta.size,0)
        np.testing.assert_array_equal(result.O,[[-1.]])
        self.assertGreater(result.loss,0.)


if __name__ == "__main__":
    unittest.main()
