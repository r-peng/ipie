"""Controlled scalar/vector oracles for the outer driver, not physics tests.

The quadratic oracle exposes exact Euclidean values and gradients. A minimal
snapshot satisfies the driver's bookkeeping contract; it does not represent
a Hamiltonian or test gauge/partition kernels. Physical integration tests
live separately in test_outer.py.
"""

from types import SimpleNamespace
import unittest
from unittest.mock import patch

import numpy as np

from ipie.hamiltonians.optimize_cholesky import (
    ExponentialEvaluation, GaugeFeasibilityError, GaugeRegularityError,
    InnerConvergenceError, OuterOptions,
)
from ipie.hamiltonians.optimize_cholesky.outer import _minimize_exponential


def readonly(value):
    result = np.array(value, dtype=float, copy=True)
    result.setflags(write=False)
    return result


class QuadraticOracle:
    """Exact f(theta)=.5*(theta-target).T@A@(theta-target), with call records.

    failure(theta,call_number) can raise an explicitly requested exception.
    Each successful call reports two dummy inner sweeps; this makes driver
    counters auditable without replacing any scientific numerical operation.
    """

    def __init__(self, matrix, target, *, failure=None, tangent_norm=None):
        self.matrix = np.atleast_2d(np.array(matrix, dtype=float))
        self.target = np.atleast_1d(np.array(target, dtype=float))
        self.reference = readonly(np.eye(max(1, self.target.size)))
        self.failure = failure
        self.tangent_norm = tangent_norm
        self.evaluations = 0
        self.failed_evaluations = 0
        self.cache_hits = 0
        self.inner_sweeps = 0
        self.visited = []
        self.points = []

    def evaluate(self, theta):
        theta = np.asarray(theta, dtype=float)
        self.evaluations += 1
        self.visited.append(theta.copy())
        if self.failure is not None:
            try:
                self.failure(theta, self.evaluations)
            except (GaugeFeasibilityError, GaugeRegularityError,
                    InnerConvergenceError, FloatingPointError, np.linalg.LinAlgError):
                self.failed_evaluations += 1
                raise
        delta = theta-self.target
        value = float(.5*delta@self.matrix@delta)
        gradient = self.matrix@delta
        tangent = gradient.reshape(1, -1)
        if self.tangent_norm is not None:
            tangent = np.array([[self.tangent_norm]])
        inner = SimpleNamespace(converged=True, sweeps=2,
                                projected_gradient_norm=0.)
        snapshot = SimpleNamespace(theta=readonly(theta))
        derivative = SimpleNamespace(loss=value,
                                     tangent_gradient=readonly(tangent),
                                     inner_result=inner,
                                     decomposition=snapshot)
        point = ExponentialEvaluation(readonly(theta), readonly(gradient), derivative)
        self.points.append(point)
        self.inner_sweeps += inner.sweeps
        return point


class ControlledOuterDriverTests(unittest.TestCase):
    def test_quadratic_convergence_armijo_and_curvature_memory(self):
        oracle = QuadraticOracle([[4., 1.], [1., 3.]], [.3, -.4])
        options = OuterOptions(max_iterations=80, memory=4, max_step_norm=.75,
                               gradient_atol=1e-9, gradient_rtol=0,
                               validate_final=False)
        result = _minimize_exponential(oracle, [1.2, .8], options)
        self.assertTrue(result.converged)
        self.assertEqual(result.status, "converged")
        np.testing.assert_allclose(result.theta, oracle.target, atol=1e-8, rtol=0)
        self.assertLessEqual(result.gradient_norm, result.gradient_threshold)
        self.assertLessEqual(result.tangent_gradient_norm, result.tangent_gradient_threshold)
        self.assertLess(result.loss, result.initial_loss)
        self.assertTrue(np.all(np.diff([row.loss for row in result.history]) <= 0))
        self.assertTrue(any(row.curvature_update for row in result.history[1:]))
        self.assertTrue(all(row.memory_size <= options.memory for row in result.history))
        previous = oracle.points[0]
        accepted_count = 0
        # Every trial here is numerically valid; points[1:] follows trial order.
        for trial, point in zip(result.trials, oracle.points[1:]):
            if trial.accepted:
                displacement = point.theta-previous.theta
                armijo_rhs = previous.loss+options.armijo*np.dot(previous.gradient_theta,
                                                               displacement)
                self.assertLessEqual(point.loss, armijo_rhs+1e-14)
                previous = point
                accepted_count += 1
                self.assertEqual(result.history[accepted_count].loss, point.loss)
        self.assertEqual(accepted_count, result.iterations)
        self.assertIs(result.evaluation, previous)
        self.assertEqual(result.evaluations, 1+len(result.trials))
        self.assertEqual(result.failed_evaluations, 0)
        self.assertEqual(result.inner_sweeps, 2*result.evaluations)
        self.assertFalse(result.theta.flags.writeable)
        self.assertFalse(result.gradient_theta.flags.writeable)

    def test_zero_iteration_and_evaluation_budgets_keep_valid_initial_state(self):
        for options, status in (
            (OuterOptions(max_iterations=0), "max_iterations"),
            (OuterOptions(max_iterations=10, max_evaluations=1), "max_evaluations"),
        ):
            with self.subTest(status=status):
                oracle = QuadraticOracle([[1.]], [3.])
                result = _minimize_exponential(oracle, [0.], options)
                self.assertFalse(result.converged)
                self.assertEqual(result.status, status)
                self.assertEqual(result.iterations, 0)
                self.assertEqual(result.evaluations, 1)
                self.assertEqual(len(result.trials), 0)
                self.assertIs(result.evaluation, oracle.points[0])
                np.testing.assert_array_equal(result.theta, [0.])

    def test_evaluation_budget_after_an_accepted_step_returns_that_step(self):
        oracle = QuadraticOracle([[1.]], [3.])
        options = OuterOptions(max_iterations=10, max_evaluations=2,
                               max_step_norm=1., gradient_atol=1e-12,
                               gradient_rtol=0)
        result = _minimize_exponential(oracle, [0.], options)
        self.assertFalse(result.converged)
        self.assertEqual(result.status, "max_evaluations")
        self.assertEqual(result.iterations, 1)
        self.assertEqual(result.evaluations, 2)
        self.assertIs(result.evaluation, oracle.points[-1])
        self.assertLess(result.loss, result.initial_loss)
        self.assertEqual(result.loss, result.history[-1].loss)

    def test_armijo_rejections_and_failed_line_search_do_not_replace_state(self):
        # The maximum allowed first displacement overshoots this sharp minimum.
        oracle = QuadraticOracle([[1000.]], [.03])
        options = OuterOptions(max_iterations=3, max_line_search=1,
                               max_step_norm=1., gradient_atol=1e-12,
                               gradient_rtol=0)
        result = _minimize_exponential(oracle, [0.], options)
        self.assertEqual(result.status, "line_search_failed")
        self.assertFalse(result.converged)
        self.assertEqual(result.iterations, 0)
        self.assertEqual(result.evaluations, 2)
        self.assertEqual(len(result.trials), 1)
        self.assertFalse(result.trials[0].accepted)
        self.assertEqual(result.trials[0].reason, "insufficient_decrease")
        self.assertGreater(oracle.points[-1].loss, oracle.points[0].loss)
        self.assertIs(result.evaluation, oracle.points[0])
        self.assertIsNot(result.evaluation, oracle.points[-1])
        np.testing.assert_array_equal(result.decomposition.theta, [0.])

    def test_budget_during_rejected_line_search_preserves_initial_point(self):
        oracle = QuadraticOracle([[1000.]], [.03])
        options = OuterOptions(max_iterations=3, max_evaluations=2,
                               max_line_search=10, max_step_norm=1.)
        result = _minimize_exponential(oracle, [0.], options)
        self.assertEqual(result.status, "max_evaluations")
        self.assertEqual(result.iterations, 0)
        self.assertEqual(result.evaluations, 2)
        self.assertIs(result.evaluation, oracle.points[0])
        self.assertTrue(all(not trial.accepted for trial in result.trials))

    def test_recoverable_large_trial_failures_can_backtrack_and_converge(self):
        exceptions = (GaugeFeasibilityError, GaugeRegularityError,
                      InnerConvergenceError, FloatingPointError, np.linalg.LinAlgError)
        for exception in exceptions:
            def failure(theta, count):
                if theta[0] > .75:
                    raise exception("controlled invalid large trial")
            with self.subTest(exception=exception.__name__):
                oracle = QuadraticOracle([[10.]], [.3], failure=failure)
                result = _minimize_exponential(
                    oracle, [0.], OuterOptions(max_iterations=25,
                                              gradient_atol=1e-10, gradient_rtol=0))
                self.assertTrue(result.converged)
                self.assertGreater(result.failed_evaluations, 0)
                np.testing.assert_allclose(result.theta, [.3], atol=1e-9, rtol=0)
                failed = [trial for trial in result.trials if trial.loss is None]
                self.assertTrue(failed)
                self.assertTrue(all(not trial.accepted for trial in failed))
                self.assertTrue(all(exception.__name__ in trial.reason for trial in failed))

    def test_failures_after_one_accepted_step_keep_the_accepted_snapshot(self):
        def failure(theta, count):
            if count > 2:
                raise InnerConvergenceError("controlled later failure")
        oracle = QuadraticOracle([[1.]], [3.], failure=failure)
        result = _minimize_exponential(
            oracle, [0.], OuterOptions(max_iterations=4, max_line_search=3,
                                      gradient_atol=1e-12, gradient_rtol=0))
        self.assertEqual(result.status, "line_search_failed")
        self.assertEqual(result.iterations, 1)
        self.assertEqual(result.failed_evaluations, 3)
        self.assertEqual(result.evaluations, 5)
        self.assertIs(result.evaluation, oracle.points[-1])
        self.assertEqual(result.loss, result.history[-1].loss)
        self.assertFalse(np.array_equal(result.theta, oracle.visited[-1]))
        self.assertEqual(result.partition_result.sweeps, 2)
        self.assertEqual(result.inner_sweeps, 4)

    def test_callback_can_stop_at_initial_or_accepted_state(self):
        for stop_iteration in (0, 1):
            records = []
            def callback(record):
                records.append(record)
                if record.iteration == stop_iteration:
                    raise StopIteration
            with self.subTest(stop_iteration=stop_iteration):
                oracle = QuadraticOracle([[1.]], [3.])
                result = _minimize_exponential(oracle, [0.], OuterOptions(), callback)
                self.assertEqual(result.status, "callback_stopped")
                self.assertFalse(result.converged)
                self.assertEqual(result.iterations, stop_iteration)
                self.assertEqual([row.iteration for row in records],
                                 list(range(stop_iteration+1)))
                self.assertEqual(result.loss, records[-1].loss)
                self.assertIs(result.evaluation, oracle.points[-1])

    def test_initial_failure_and_programming_errors_propagate(self):
        initial_error = GaugeRegularityError("controlled invalid initial point")
        def initial_failure(theta, count):
            raise initial_error
        oracle = QuadraticOracle([[1.]], [3.], failure=initial_failure)
        with self.assertRaises(GaugeRegularityError) as caught:
            _minimize_exponential(oracle, [0.], OuterOptions())
        self.assertIs(caught.exception, initial_error)
        self.assertEqual(oracle.evaluations, 1)
        for exception in (NotImplementedError, TypeError, AttributeError, ValueError, RuntimeError):
            error = exception("controlled programming/configuration error")
            def failure(theta, count):
                if count == 2:
                    raise error
            with self.subTest(exception=exception.__name__):
                oracle = QuadraticOracle([[1.]], [3.], failure=failure)
                with self.assertRaises(exception) as caught:
                    _minimize_exponential(oracle, [0.], OuterOptions())
                self.assertIs(caught.exception, error)
                self.assertEqual(oracle.evaluations, 2)
        oracle = QuadraticOracle([[1.]], [3.])
        with self.assertRaises(TypeError):
            _minimize_exponential(oracle, [0.], OuterOptions(), callback=1)
        self.assertEqual(oracle.evaluations, 0)

    def test_negative_curvature_is_not_retained(self):
        oracle = QuadraticOracle([[-1.]], [0.])
        result = _minimize_exponential(
            oracle, [.2], OuterOptions(max_iterations=3, gradient_atol=0,
                                      gradient_rtol=0, max_step_norm=.3))
        self.assertEqual(result.status, "max_iterations")
        self.assertFalse(result.converged)
        self.assertEqual(result.iterations, 3)
        self.assertTrue(all(not row.curvature_update for row in result.history))
        self.assertTrue(all(row.memory_size == 0 for row in result.history))
        self.assertTrue(np.all(np.diff([row.loss for row in result.history]) < 0))

    def test_bad_quasi_newton_direction_falls_back_to_descent(self):
        oracle = QuadraticOracle([[1.]], [3.])
        # This replaces only the optimization helper with a deliberately bad
        # direction. No Hamiltonian, linear-algebra or derivative kernel is mocked.
        with patch("ipie.hamiltonians.optimize_cholesky.solvers.lbfgs._lbfgs_direction",
                   side_effect=lambda gradient, pairs: gradient.copy()):
            result = _minimize_exponential(
                oracle, [0.], OuterOptions(max_iterations=10, gradient_atol=1e-9,
                                          gradient_rtol=0))
        self.assertTrue(result.converged)
        self.assertLess(result.loss, result.initial_loss)
        np.testing.assert_allclose(result.theta, [3.], atol=1e-8, rtol=0)

    def test_coordinate_gradient_alone_does_not_certify_stationarity(self):
        oracle = QuadraticOracle([[1.]], [0.], tangent_norm=1.)
        result = _minimize_exponential(
            oracle, [0.], OuterOptions(gradient_atol=1e-9, gradient_rtol=0))
        self.assertEqual(result.gradient_norm, 0.)
        self.assertEqual(result.tangent_gradient_norm, 1.)
        self.assertEqual(result.status, "coordinate_stalled")
        self.assertFalse(result.converged)
        self.assertEqual(result.evaluations, 1)

    def test_zero_dimensional_coordinate_problem_is_evaluated_once(self):
        oracle = QuadraticOracle(np.empty((0, 0)), np.empty(0))
        result = _minimize_exponential(oracle, np.empty(0), OuterOptions())
        self.assertTrue(result.converged)
        self.assertEqual(result.status, "converged")
        self.assertEqual(result.evaluations, 1)
        self.assertEqual(result.iterations, 0)
        self.assertEqual(result.theta.shape, (0,))


if __name__ == "__main__":
    unittest.main()
